function rng(x)
  randn('seed', x)
  rand('seed', x)
end